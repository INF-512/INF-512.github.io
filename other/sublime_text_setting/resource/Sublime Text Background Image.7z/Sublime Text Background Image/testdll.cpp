#include <windows.h>
#include <bits/stdc++.h>
using namespace std;
// #ifndef NDEBUG
#define myassert(expr) ((expr) ? void(0) : (print("Assertion failed: {}, file {}, line {}\n", #expr, __FILE__,__LINE__), abort()))
// #else
// #define myassert(expr) void(0)
// #endif
#define print(...) OutputDebugString(("test - " + format(__VA_ARGS__)).c_str())

HANDLE hEvent;
HANDLE hMapFile;
LPCTSTR pBuf, pBuf2;

struct MyQueue {
  CWPSTRUCT a[1000];
  volatile int l, r;
  void push(const CWPSTRUCT& msg) {
    a[r] = msg;
    if (++r == 1000)
      r = 0;
    myassert(l != r);
  }
  CWPSTRUCT pop() {
    myassert(l != r);
    CWPSTRUCT msg = a[l];
    if (++l == 1000)
      l = 0;
    return msg;
  }
  bool is_empty() {
    return l == r;
  }
};

MyQueue *q;
#define BUF_SIZE sizeof(MyQueue)

LPCTSTR get_addr(int sz) {
  LPCTSTR ret = pBuf2; pBuf2 += sz;
  return ret;
}

void init_var() {
  q = (MyQueue*)get_addr(sizeof(MyQueue));
}

extern "C" LRESULT CALLBACK WindowProc(int nCode, WPARAM wParam, LPARAM lParam) {
  if (nCode == HC_ACTION) {
    CWPSTRUCT* msg = (CWPSTRUCT*)lParam;
    // 49234 648 642
    // if (msg->message != 132 && msg->message != 32 && msg->message <= 49000 && msg->message != 648 && msg->message != 642 && msg->message != 13) {
    if (msg->message == WM_SIZE || msg->message == WM_MOVE || msg->message == WM_ACTIVATE/* || msg->message == WM_DESTROY*/ || msg->message == 144) {
      char classname[205], windowname[205];
      GetClassName(msg->hwnd, classname, sizeof(classname));
      if (strcmp(classname, "PX_WINDOW_CLASS") == 0) {
        GetWindowText(msg->hwnd, windowname, sizeof(windowname));
        if (strstr(windowname, " - Sublime Text")) {
          // print("msg->message={}", msg->message);
          q->push(*msg);
          SetEvent(hEvent);
        }
      }
    }
  }
  return CallNextHookEx(NULL, nCode, wParam, lParam);
}

void init() {
  hMapFile = OpenFileMapping(FILE_MAP_ALL_ACCESS, FALSE, "Local\\MyFileMappingObject265565534");
  myassert(hMapFile);
  pBuf = pBuf2 = (LPTSTR) MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, BUF_SIZE);
  myassert(pBuf);
  init_var();
  hEvent = OpenEvent(EVENT_MODIFY_STATE, FALSE, "MyNamedEvent2153213456");
  myassert(hEvent);
}

void uninit() {
  UnmapViewOfFile(pBuf);
  CloseHandle(hMapFile);
  CloseHandle(hEvent);
}

BOOL WINAPI DllMain(
  HINSTANCE hinstDLL,  // handle to DLL module
  DWORD fdwReason,     // reason for calling function
  LPVOID lpvReserved)  // reserved
{
  // OutputDebugString("test - DllMain");
  // Perform actions based on the reason for calling.
  switch (fdwReason)
  {
  case DLL_PROCESS_ATTACH:
    // Initialize once for each new process.
    // Return FALSE to fail DLL load.
    OutputDebugString("test - DLL_PROCESS_ATTACH");
    init();
    
    break;

  case DLL_THREAD_ATTACH:
    // Do thread-specific initialization.
    // OutputDebugString("test - DLL_THREAD_ATTACH");
    break;

  case DLL_THREAD_DETACH:
    // Do thread-specific cleanup.
    // OutputDebugString("test - DLL_THREAD_DETACH");
    break;

  case DLL_PROCESS_DETACH:

    if (lpvReserved != nullptr)
    {
      // OutputDebugString("test - DLL_PROCESS_DETACH1");
      break; // do not do cleanup if process termination scenario
    }
    // Perform any necessary cleanup.
    OutputDebugString("test - DLL_PROCESS_DETACH2");
    // uninit();
    break;
  }
  return TRUE;  // Successful DLL_PROCESS_ATTACH.
}