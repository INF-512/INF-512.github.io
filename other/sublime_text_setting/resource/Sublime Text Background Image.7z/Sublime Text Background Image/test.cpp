// #include <bits/stdc++.h>
// #include <windows.h>
// #include "cimg.h"
// using namespace std;
// using namespace cimg_library;
// #define pii pair<int, int>
// #define all(x) (x).begin(), (x).end()
// #define endl '\n'
// // #define endl " line in : " << __LINE__ << endl
// signed main() {

//   return 0;
// }
#include <bits/stdc++.h>
#include <windows.h>
#include "cimg.h"
using namespace std;
using namespace cimg_library;
namespace fs = std::filesystem;

#define ZOOM 1.5

int screen_width, screen_height;
CImg<unsigned char> img;
double rat;

HBRUSH bg_brush;

struct MySub {
  HWND hwnd;
  int x, y, w, h;
  unsigned char *buf;
  int rsz;
  MySub(HWND hwnd = 0, int x = 0, int y = 0, int w = 0, int h = 0) {
    this->hwnd = hwnd, this->x = x, this->y = y, this->w = w, this->h = h, rsz = 1;
  }
};

map<HWND, MySub> mySub;
map<HWND, HWND> wnd2sub;

vector<string> img_names;
int cur_index;

void load_img(const char *filename) {
  img.assign(filename);
  cout << sizeof(img) << endl;
  int w = img.width(), h = img.height();
  cout << w << ' ' << h << ' ' << endl;
  rat = 1.0 * w / h;
  if (w > screen_width || h > screen_height) {
    w = screen_width, h = w / rat;
    if (h > screen_height)
      h = screen_height, w = h * rat;
  }
  img.resize(w, h, -100, -100, 3);
  for (auto&& [k, v] : mySub) {
    v.rsz = 1;
    InvalidateRect(v.hwnd, NULL, TRUE);
  }
}

void draw_img(HDC& hdc, HWND hwnd, int width, int height) {
  int w = width, h = w / rat, c;
  if (h > height)
    h = height, w = h * rat;
  w = w / 4 * 4;
  
  HWND hsub = wnd2sub[hwnd];
  int& rsz = mySub[hsub].rsz;
  unsigned char *buf = mySub[hsub].buf;
  
  if (rsz) {
    CImg<unsigned char> img2 = img.get_resize(w, h, -100, -100, 3);
    cimg_forXY(img2, x, y) {
      buf[(y * w + x) * 3 + 0] = img2(x, y, 2);
      buf[(y * w + x) * 3 + 1] = img2(x, y, 1);
      buf[(y * w + x) * 3 + 2] = img2(x, y, 0);
    }
    rsz = 0;
  }

  BITMAPINFO bmi = {};
  bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  bmi.bmiHeader.biWidth = w;
  bmi.bmiHeader.biHeight = -h;
  bmi.bmiHeader.biPlanes = 1;
  bmi.bmiHeader.biBitCount = 24;
  bmi.bmiHeader.biCompression = BI_RGB;

  SetDIBitsToDevice(hdc, width - w, (height - h) / 2, w, h, 0, 0, 0, h, buf, &bmi, DIB_RGB_COLORS);

  RECT rc;
  rc = { 0, 0, width, (height - h) / 2 };
  FillRect(hdc, &rc, bg_brush);
  rc = { 0, 0, width - w, height };
  FillRect(hdc, &rc, bg_brush);
  rc = { 0, height - (height - h) / 2, width, height };
  FillRect(hdc, &rc, bg_brush);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
  switch (msg) {
  case WM_PAINT: {
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(hwnd, &ps);
    RECT rect;
    GetClientRect(hwnd, &rect);
    draw_img(hdc, hwnd, rect.right, rect.bottom);
    EndPaint(hwnd, &ps);
    break;
  }
  case WM_SIZE: {
    HWND hsub = wnd2sub[hwnd];
    int& rsz = mySub[hsub].rsz;
    rsz = 1;
    InvalidateRect(hwnd, NULL, TRUE);
    // UpdateWindow(hWnd);
    break;
  }
  case WM_KEYDOWN: {
    cout << format("WM_KEYDOWN, wParam={}", wParam) << endl;
    if (wParam == 37) { // 左方向键
      cur_index = cur_index == 0 ? img_names.size() - 1 : cur_index - 1;
      cout << format("picture_path = {}", img_names[cur_index]) << endl;
      load_img(img_names[cur_index].c_str());
    }
    else if (wParam == 39) { // 右方向键
      cur_index = cur_index + 1 == img_names.size() ? 0 : cur_index + 1;
      cout << format("picture_path = {}", img_names[cur_index]) << endl;
      load_img(img_names[cur_index].c_str());
    }
    break;
  }
  case WM_DESTROY:
    PostQuitMessage(0);
    break;
  default:
    return DefWindowProc(hwnd, msg, wParam, lParam);
  }
  return 0;
}

HANDLE hEvent;
HANDLE hMapFile;
HMODULE hdll;
HHOOK hhook;
LPCTSTR pBuf, pBuf2;

struct MyQueue {
  CWPSTRUCT a[1000];
  volatile int l, r;
  void push(const CWPSTRUCT& msg) {
    a[r] = msg;
    if (++r == 1000)
      r = 0;
    assert(l != r);
  }
  CWPSTRUCT pop() {
    assert(l != r);
    CWPSTRUCT msg = a[l];
    if (++l == 1000)
      l = 0;
    return msg;
  }
  bool is_empty() {
    return l == r;
  }
};

MyQueue *q;
#define BUF_SIZE sizeof(MyQueue)

LPCTSTR get_addr(int sz) {
  LPCTSTR ret = pBuf2; pBuf2 += sz;
  return ret;
}
void init_var() {
  q = (MyQueue*)get_addr(sizeof(MyQueue));
  q->l = 0, q->r = 0;
}

void save_index() {
  HKEY hKey;
  DWORD disposition;
  // 打开或创建注册表项 HKEY_cur_indexRENT_USER\Software\MyApp
  RegCreateKeyEx(
    HKEY_CURRENT_USER,
    "Software\\" "Sublime Text Background Image",
    0,
    NULL,
    REG_OPTION_NON_VOLATILE,  // 表示注册表项将在系统重启后保留
    KEY_WRITE,
    NULL,
    &hKey,
    &disposition
  );

  const char *valueName = "cur_index";
  DWORD valueData = cur_index;
  RegSetValueEx(
    hKey,
    valueName,
    0,
    REG_DWORD,
    (BYTE*)&valueData,
    sizeof(valueData)
  );
  RegCloseKey(hKey);
}

void load_index() {
  HKEY hKey;
  DWORD dwType;
  DWORD dwSize = sizeof(DWORD);
  // 打开注册表项 HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion
  RegOpenKeyEx(
    HKEY_CURRENT_USER,
    TEXT("Software\\" "Sublime Text Background Image"),
    0,
    KEY_READ,
    &hKey
  );
  // 读取注册表项的 "MyValue" 值
  RegQueryValueEx(
    hKey,
    "cur_index",
    NULL,
    &dwType,
    (LPBYTE)&cur_index,
    &dwSize
  );
  // 关闭注册表项句柄
  RegCloseKey(hKey);
}

void init() {
  hMapFile = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, BUF_SIZE, "Local\\MyFileMappingObject265565534");
  assert(hMapFile);
  pBuf = pBuf2 = (LPTSTR) MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, BUF_SIZE);
  assert(pBuf);
  init_var();
  hEvent = CreateEvent(NULL, TRUE, FALSE, "MyNamedEvent2153213456");
  assert(hEvent);

  screen_width = GetSystemMetrics(SM_CXSCREEN);
  screen_height = GetSystemMetrics(SM_CYSCREEN);
  // load_img("123.jpg");
  bg_brush = CreateSolidBrush(0);
  cout << "load image list..." << endl;
  for (const auto &file : fs::directory_iterator("./imgs"))
    img_names.push_back(file.path().string());
  cout << format("total: {}", img_names.size()) << endl;
  load_index();
  if (cur_index < 0 || cur_index >= img_names.size())
    cur_index = 0;
  cout << format("cur_index = {}", cur_index) << endl;
  load_img(img_names[cur_index].c_str());
}

void uninit() {
  UnhookWindowsHookEx(hhook);
  FreeLibrary(hdll);
  UnmapViewOfFile(pBuf);
  CloseHandle(hMapFile);
  CloseHandle(hEvent);
  DeleteObject(bg_brush);
  save_index();
}

void MyCreateWindow(HWND hsub) {
  HINSTANCE hInstance = GetModuleHandle(NULL);
  WNDCLASS wc = {};
  wc.lpfnWndProc = WndProc;
  wc.hInstance = hInstance;
  wc.lpszClassName = "SUBLIME_TEXT_BACKGROUND_IMAGE";

  RegisterClass(&wc);

  HWND hwnd = CreateWindowEx(0, "SUBLIME_TEXT_BACKGROUND_IMAGE", "Sublime Text Background Image", /*WS_OVERLAPPEDWINDOW*/WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT, 400, 300, NULL, NULL, hInstance, NULL);

  // ShowWindow(hwnd, nCmdShow);
  ShowWindow(hwnd, SW_SHOW);

  RECT rc;
  GetWindowRect(hsub, &rc);
  mySub[hsub] = MySub(hwnd, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
  mySub[hsub].buf = new unsigned char[screen_width*screen_height*3];
  wnd2sub[hwnd] = hsub;
  SetWindowPos(hwnd, hsub, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, SWP_NOACTIVATE);

  MSG msg;
  while (GetMessage(&msg, NULL, 0, 0)) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
}

void MsgProc() {

  hdll = LoadLibrary("testdll.dll");
  assert(hdll);

  hhook = SetWindowsHookEx(WH_CALLWNDPROC, (HOOKPROC)GetProcAddress(hdll, "WindowProc"), hdll, 0);
  assert(hhook);

  int cnt = 0, pre = 0;
  HWND last = NULL;

  while (1) {
    if (q->is_empty()) {
      if (++cnt == 100000000) {
        cout << "wait..." << endl;
        auto&& [hwnd, x, y, w, h, buf, rsz] = mySub[last];
        SetWindowPos(hwnd, last, x, y, w, h, SWP_NOACTIVATE);
        ResetEvent(hEvent);
        WaitForSingleObject(hEvent, INFINITE);
        cout << "wait end" << endl;
        cnt = 0;
      }
    }
    else {
      cnt = 0;
      CWPSTRUCT msg = q->pop();
      HWND hsub = msg.hwnd;
      if (mySub.count(hsub) == 0) {
        mySub[hsub] = {};
        new thread(MyCreateWindow, hsub);
      }
      auto&& [hwnd, x, y, w, h, buf, rsz] = mySub[hsub];
      if (hwnd == 0 || IsWindow(hwnd) == 0 || IsWindow(hsub) == 0)
        continue;
      last = hsub;
      if (msg.message == WM_SIZE) {
        w = LOWORD(msg.lParam) / ZOOM, h = HIWORD(msg.lParam) / ZOOM;
        cout << format("w = {}, h = {}", w, h) << endl;
        int now = clock();
        if (now - pre > 500) {
          SetWindowPos(hwnd, hsub, 0, 0, w, h, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
          pre = now;
        }
      }
      else if (msg.message == WM_MOVE) {
        cout << "WM_MOVE" << endl;
        short xx = LOWORD(msg.lParam), yy = HIWORD(msg.lParam);
        x = xx / ZOOM, y = yy / ZOOM;
        cout << format("x = {}, y = {}", x, y) << endl;
        SetWindowPos(hwnd, hsub, x, y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
      }
      else if (msg.message == WM_ACTIVATE) {
        cout << "WM_ACTIVATE" << endl;
        SetWindowPos(hwnd, hsub, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE);
      }
      else if (/*msg.message == WM_DESTROY || */msg.message == 144) {
        cout << "WM_DESTROY" << endl;
        SendMessage(hwnd, WM_CLOSE, 0, 0);
        while (!q->is_empty())
          msg = q->pop();
        delete[] mySub[hsub].buf;
        mySub.erase(hsub);
      }
      else {
        // if (msg.message == 533 || msg.message==144 || msg.message==70 || msg.message==71||msg.message==134)
        cout << "msg.message=" << msg.message << endl;
      }
    }
  }
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
  init();
  new thread(MsgProc);
  int t; cin >> t;
  uninit();
  return 0;
}
